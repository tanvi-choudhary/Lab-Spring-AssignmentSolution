package com.gl.student.dao;


//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.student.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

	//List<Student> findByNameContainsAllIgnoreCase(String firstName);

	//List<Student> findAllByOrderByNameAsc();

}