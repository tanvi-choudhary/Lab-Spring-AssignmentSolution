package com.gl.student.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.student.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
