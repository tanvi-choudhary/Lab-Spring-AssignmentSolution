package com.gl.student.service;

import java.util.List;

import com.gl.student.entity.Student;
import com.gl.student.entity.Role;
import com.gl.student.entity.User;

public interface StudentService {

	public List<Student> findAll();
	
	public Student findById(int theId);
	
	public void save(Student theStudent);
	
	public void deleteById(int theId);
	
	
	public User saveUser(User user);
	
	public Role saveRole(Role role);
}

