package com.gl.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSecurityApplication.class, args);
	}

}
